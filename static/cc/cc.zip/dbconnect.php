<?php
//$connect=mysqli_connect("localhost","root","","iot_healthmonitor");
//$connect=mysqli_connect("localhost","iotcl6k4_iotuser","IOTcloud@2021","iotcl6k4_project22");



?>